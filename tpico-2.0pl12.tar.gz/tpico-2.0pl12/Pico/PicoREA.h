             /*-----------------------------------*/
             /*           >>>Pico 2.0<<<          */
             /*            Theo D'Hondt           */
             /*   VUB Programming Technology Lab  */
             /*             (c) 2002              */
             /*-----------------------------------*/
             /*            Reading (_)            */
             /*-----------------------------------*/

/*----------------------- public functions ------------------------*/

_EXP_TYPE_ _read_(_STR_TYPE_);

_NIL_TYPE_ _rea_EXP_(_NIL_TYPE_);

