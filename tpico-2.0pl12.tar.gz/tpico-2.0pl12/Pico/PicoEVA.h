             /*-----------------------------------*/
             /*           >>>Pico 2.0<<<          */
             /*            Theo D'Hondt           */
             /*   VUB Programming Technology Lab  */
             /*             (c) 2002              */
             /*-----------------------------------*/
             /*            Evaluation             */
             /*-----------------------------------*/

/*---------------------- private variables ------------------------*/

extern _CNT_TYPE_ _eva_EXP_;
extern _CNT_TYPE_ _eva_CAL_;

